import javax.swing.JApplet;

public class SimpleDrawRectsApplet extends JApplet{

   public void init() {
      setContentPane( new SimpleDrawRects() );
   }
   
}
