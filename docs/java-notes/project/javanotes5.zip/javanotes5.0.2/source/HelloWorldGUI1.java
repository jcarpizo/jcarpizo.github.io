import javax.swing.JOptionPane;

/**
 * A trivial GUI program that says "Hello World" to the user,
 * using the buitl-in JOptionPane class.
 */
public class HelloWorldGUI1 {

   public static void main(String[] args) {
         JOptionPane.showMessageDialog( null, "Hello World!");
   }
   
}
